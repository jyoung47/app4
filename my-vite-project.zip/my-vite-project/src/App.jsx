import { useState } from 'react';
import './App.css';
import Homepage from './Components/Homepage';
import EmployeePage from './Components/EmployeePage';

export default function App(){


  return (
    <div className='app'>
         <Homepage/>
    <EmployeePage/>
    
    </div>
  )
  }

 