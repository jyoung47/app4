import Header from './Header';
import './employeePage.css'

export default function EmployeePage(){
    
    return (
      <div className='employeepage'>
          
          <Header title = "Employee"/>
          <div className='employeeOverview'>
                    <h3>Julie Taylor</h3>
                    <p>VP of Marketing</p>
                    </div>
        <div className='employeeOffice'>
            <h3>Call Office</h3>
            <p>781-000-0002</p>
            </div>
            <div className='employeeMobile'>
            <h4>Call Mobile</h4>
            <p>781-516-8485</p>
            </div>
            <div className='employeeSMS'>
          <h4>SMS</h4>
            <p>781-516-8485</p>    
            </div>          
                     <div className='employeeEmail'>
          <h4>Email</h4>
            <p>jtaylor@fakemail.com</p>
            </div>
              
        
      </div>
    );
};