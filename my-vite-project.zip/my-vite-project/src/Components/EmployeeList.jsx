import EmployeeListitem from './EmployeeListitem';
import './employeeList.css'
export default function EmployeeList(){
    
    return (
      <div className='employeelist'>
      
      <EmployeeListitem employeeName = 'James King' employeeTitle = 'President and CEO'/>
      <EmployeeListitem employeeName = 'Julie Taylor' employeeTitle = 'VP of Marketing'/>
      <EmployeeListitem employeeName = 'Eugene Lee' employeeTitle = 'CFO'/>
      <EmployeeListitem employeeName = 'John Williams' employeeTitle = 'VP of Engineering'/>
      <EmployeeListitem employeeName = 'Ray Moore' employeeTitle = 'VP of Sales'/>
      <EmployeeListitem employeeName = 'Paul Jones' employeeTitle = 'QA Manager'/>
           </div>
    );
};