import './searchbar.css'
export default function SearchBar(){
    
    return (
      <div className="search">
          <input placeholder='search'/>
      </div>
    );
};