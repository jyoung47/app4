import './employeelistitem.css';

export default function EmployeeListItem({ employeeName, employeeTitle }) {
  return (
    <div className='employeelistitem'>
      <img src="path-to-your-image.jpg" alt="Employee" />
      <h3>{employeeName}</h3>
      <p>{employeeTitle}</p>
    </div>
  );
};
